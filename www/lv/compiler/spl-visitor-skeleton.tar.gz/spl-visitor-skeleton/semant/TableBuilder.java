package semant;

import sym.Sym;
import table.*;
import types.*;
import absyn.*;

class TableBuilder {

	private boolean showTables;

	Table buildSymbolTables(Absyn program, boolean showTables) {
	}
    
	private class TableBuilderVisitor extends DoNothingVisitor {

		public void visit(DecList list) {

		}

		public void visit(TypeDec node) {

		}

		public void visit(NameTy node) {

		}

		public void visit(ArrayTy node) {

		}

		public void visit(ProcDec node) {

		}

		public void visit(ParDec node) {

		}

		public void visit(VarDec node) {

		}
	}
}


