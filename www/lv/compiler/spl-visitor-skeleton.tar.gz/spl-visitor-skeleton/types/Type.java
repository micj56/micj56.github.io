/*
 * Type.java -- type representation
 */


package types;


public abstract class Type {

  public int byteSize;

  public abstract void show();

}
