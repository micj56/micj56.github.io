/*
 * Entry.java -- an abtract class representing a table entry
 */


package table;


public abstract class Entry {

  public abstract void show();

}
