/*
 * Ty.java -- abstract syntax for types
 */


package absyn;


public abstract class Ty extends Absyn {

}
