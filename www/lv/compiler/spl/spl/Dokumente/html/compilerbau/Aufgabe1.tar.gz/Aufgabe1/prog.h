/*
 * prog.h -- ein kleines SLPL-Programm
 */


#ifndef _PROG_H_
#define _PROG_H_


Knoten *konstruiereProgramm(void);


#endif /* _PROG_H_ */
