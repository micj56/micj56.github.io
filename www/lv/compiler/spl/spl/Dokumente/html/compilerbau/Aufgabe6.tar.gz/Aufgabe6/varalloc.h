/*
 * varalloc.h -- variable allocation
 */


#ifndef _VARALLOC_H_
#define _VARALLOC_H_


void allocVars(Absyn *program, Table *globalTable, boolean showVarAlloc);


#endif /* _VARALLOC_H_ */
