package semant;

import table.*;
import types.*;
import absyn.*;

/** 

    unvollständiges Skelett als Vorschlag
   -->  ergänzen oder ignorieren und auf andere Weise implementieren 

**/

class ProcedureBodyChecker {

    private Table symTable;   // table for current scope

    void procedureBodyCheck (Absyn program, Table globalTable) {
	/* Implementierung nach Visitor-Muster */
	program.accept(new  procedureBodyCheckVisitor(globalTable));
    }

    private class procedureBodyCheckVisitor extends DoNothingVisitor {

	private procedureBodyCheckVisitor(Table table) {
	    symTable = table;
	}

	public void visit(ProcDec procDec) {
	    
	}

	public void visit(CompStm node) {
	    
	}
    }
}
