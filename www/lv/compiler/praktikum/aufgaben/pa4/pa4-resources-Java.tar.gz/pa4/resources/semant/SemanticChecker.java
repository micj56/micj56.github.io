/* Semant.java -- semantic checks */

package semant;

import absyn.*;
import sym.Sym;
import table.*;
import types.*;

/** 

    unvollständiges Skelett als Vorschlag
   -->  ergänzen oder ignorieren und auf andere Weise implementieren 

**/

public class SemanticChecker {

    /* primitive Typen: */
    static final Type intType = new PrimitiveType("int");
    static final Type boolType = new PrimitiveType("boolean");

    /* globale Symboltrabelle */
    static Table globalTable = new Table();

    /* semantischen Analyse  */
    public Table semanticCheck(Absyn program, boolean showTables) {
	/* Durchgang 1: Symboltabellen und Typen konstruieren */
	globalTable = new TableBuilder().buildSymbolTables(program, showTables);

	/* Durchgang 2: Prozedurrümpfe prüfen */
	new ProcedureBodyChecker().procedureBodyCheck(program);

	/* prüfen, ob main-Prozedur vorhanden */
	checkMainProcedure();
	return globalTable;
    }

    private void checkMainProcedure() {
    }
}

