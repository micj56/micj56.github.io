/*
 * Stm.java -- abstract syntax for statements
 */


package absyn;


public abstract class Stm extends Absyn {

}
