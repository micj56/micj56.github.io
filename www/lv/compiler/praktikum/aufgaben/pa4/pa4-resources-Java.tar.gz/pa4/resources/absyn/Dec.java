/*
 * Dec.java -- abstract syntax for declarations
 */


package absyn;


public abstract class Dec extends Absyn {
}
