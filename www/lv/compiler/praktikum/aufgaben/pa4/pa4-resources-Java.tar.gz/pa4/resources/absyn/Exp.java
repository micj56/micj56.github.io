/*
 * Exp.java -- abstract syntax for expressions
 */

package absyn;

import types.Type;


public abstract class Exp extends Absyn {

  public Type dataType;

}
