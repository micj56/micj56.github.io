/*
 * semant.h -- semantic analysis
 */


#ifndef _SEMANT_H_
#define _SEMANT_H_


Table *check(Absyn *program, boolean showSymbolTables);


#endif /* _SEMANT_H_ */
