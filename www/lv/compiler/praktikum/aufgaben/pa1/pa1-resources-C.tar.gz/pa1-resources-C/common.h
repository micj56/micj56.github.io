/*
 * common.h -- common definitions
 */


#ifndef _COMMON_H_
#define _COMMON_H_


typedef int boolean;

#define FALSE		0
#define TRUE		1


#endif /* _COMMON_H_ */
