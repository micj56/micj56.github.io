/*
 * codegen.h -- ECO32 code generator
 */


#ifndef _CODEGEN_H_
#define _CODEGEN_H_


void genCode(Absyn *program, Table *globalTable, FILE *outFile);


#endif /* _CODEGEN_H_ */
