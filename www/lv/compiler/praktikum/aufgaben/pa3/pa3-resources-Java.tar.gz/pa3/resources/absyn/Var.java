/*
 * Var.java -- abstract syntax for variables
 */


package absyn;

import sym.Sym;


public abstract class Var extends Absyn {

  public abstract void show(int n);

}
