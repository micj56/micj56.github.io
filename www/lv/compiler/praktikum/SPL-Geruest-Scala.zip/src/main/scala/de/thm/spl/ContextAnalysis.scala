package de.thm.spl

object ContextAnalysis {
  def apply(abstractSyntax: syntax.Program): syntax.Program = ???
}
