package de.thm.spl

import syntax.Program
import de.thm.puck

object CodeGenerator {
  def apply(ast: Program): List[puck.assembler.AbstractSyntax.AssemblerLine] = ???
}
