package de.thm.spl.symbols

class SymbolTable extends DefinitionScope(None)

