Dieses Projekt beinhaltet das Grundger�st f�r den SPL-Compiler in der Sprache Scala. 
Wir empfehlen IntelliJ mit dem offiziellen Scala Plugin zur Entwicklung.